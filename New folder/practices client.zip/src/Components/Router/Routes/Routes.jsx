import { createBrowserRouter } from "react-router-dom";
import Home from "../../Home";
import Main from "../../Main";
import Courses from "../../Courses";

const router = createBrowserRouter([
  {
    path: "/",
    element: <Main />,
    children: [
      {
        path: "/",
        element: <Home />,
      },
      {
        path: "/home",
        element: <Home />,
      },
      {
        path: "/courses",
        element: <Courses />
      },
      // {
      //     path: '/home',
      //     element: <Home/>
      // }
    ],
  },
]);

export default router;
